#   a117_append_list.py
new_list = ["dog", "cat", "mouse", "bird", "monkey"]
new_list.append("lion") 
print("list now is", new_list)

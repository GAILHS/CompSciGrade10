#   a117_pop_list.py
new_list = ["dog", "cat", "mouse", "bird", "monkey"]
item = new_list.pop()
print("popped ", item)
print("list now is", new_list)

new_list = ["dog", "cat", "mouse", "bird", "monkey"]
for animal in new_list:
  print("next animal:")
  print(animal)

i = int(input("enter number: "))
limit = 10  # for example
while i <= limit:
    print(i)
    i = i + 1
print("Loop ended at", i)
